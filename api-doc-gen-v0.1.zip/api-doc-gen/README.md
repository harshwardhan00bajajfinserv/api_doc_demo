# AI-Powered API Documentation Generator v0.1

Automatically generate API documentation from GitHub repositories using a local LLM (Ollama).

## Stack
- **Frontend**: Streamlit
- **Backend**: Flask
- **Database**: PostgreSQL
- **LLM**: Ollama (llama3 + nomic-embed-text)
- **Scheduler**: APScheduler

---

## Setup

### 1. PostgreSQL

```bash
psql -U postgres
CREATE DATABASE apidocs;
\c apidocs
CREATE TABLE docs (
    id SERIAL PRIMARY KEY,
    api_name TEXT,
    content TEXT,
    embeddings FLOAT[]
);
\q
```

### 2. Ollama

```bash
# Install Ollama: https://ollama.ai
ollama pull llama3
ollama pull nomic-embed-text
ollama serve   # runs on http://localhost:11434
```

### 3. Python Dependencies

```bash
pip install -r requirements.txt
```

### 4. Environment

```bash
cp .env.example .env
# Edit .env with your DB credentials and GitHub token
```

### 5. Run Backend

```bash
cd api-doc-gen
python -m backend.app
```

### 6. Run Frontend

```bash
streamlit run frontend/app.py
```

### 7. Run Scheduler (optional standalone)

```bash
python scheduler/cron_jobs.py
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/generate-docs` | Generate docs from GitHub repo |
| GET | `/docs` | List all documents |
| GET | `/docs/<api_name>` | Fetch a document |
| GET | `/download/<api_name>` | Download as Markdown |
| POST | `/upload-doc` | Upload .md or .txt file |
| GET | `/health` | Health check |

---

## Run Tests

```bash
pytest tests/ -v
```

---

## Project Structure

```
api-doc-gen/
├── frontend/app.py          # Streamlit UI
├── backend/
│   ├── app.py               # Flask app factory
│   ├── config.py            # Environment config
│   ├── routes/              # Flask blueprints
│   ├── services/            # Business logic
│   ├── database/            # DB connection + queries
│   └── utils/               # Helpers
├── scheduler/cron_jobs.py   # Standalone scheduler
├── tests/                   # Pytest tests
├── requirements.txt
└── .env.example
```
