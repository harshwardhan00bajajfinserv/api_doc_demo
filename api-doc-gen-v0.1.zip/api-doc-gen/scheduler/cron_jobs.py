"""
Standalone scheduler entrypoint.
Run this separately if you don't want the scheduler embedded in Flask.
"""
import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.services.scheduler_service import start_scheduler, sync_all_repos
from backend.utils.logger import get_logger

logger = get_logger("cron")

if __name__ == "__main__":
    logger.info("Starting standalone scheduler...")
    start_scheduler()
    logger.info("Scheduler running. Press Ctrl+C to exit.")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("Scheduler stopped.")
