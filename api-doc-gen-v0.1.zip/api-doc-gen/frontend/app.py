import streamlit as st
import requests
import os

BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:5000")

st.set_page_config(page_title="API Doc Generator", page_icon="📄", layout="wide")
st.title("📄 AI-Powered API Documentation Generator")

# --- Sidebar ---
st.sidebar.header("Navigation")
page = st.sidebar.radio("Go to", ["Generate Docs", "Browse Docs", "Upload Doc"])

# --- Generate Docs Page ---
if page == "Generate Docs":
    st.header("Generate Documentation from GitHub")
    repo_url = st.text_input("GitHub Repository URL", placeholder="https://github.com/owner/repo")

    if st.button("Generate", type="primary"):
        if not repo_url.startswith("https://github.com/"):
            st.error("Please enter a valid GitHub URL.")
        else:
            with st.spinner("Fetching repository and generating documentation..."):
                try:
                    r = requests.post(f"{BACKEND_URL}/generate-docs",
                                      json={"repo_url": repo_url}, timeout=300)
                    if r.status_code == 200:
                        result = r.json()
                        st.success(f"✅ Done! Docs generated: {result.get('docs_generated', 0)}")
                        st.json(result)
                    else:
                        st.error(f"Error: {r.json().get('error', 'Unknown error')}")
                except requests.exceptions.ConnectionError:
                    st.error("Cannot connect to backend. Is Flask running?")
                except Exception as e:
                    st.error(f"Error: {e}")

# --- Browse Docs Page ---
elif page == "Browse Docs":
    st.header("Browse Stored Documentation")

    try:
        r = requests.get(f"{BACKEND_URL}/docs", timeout=10)
        if r.status_code == 200:
            docs = r.json()
            if not docs:
                st.info("No documentation stored yet.")
            else:
                for doc in docs:
                    with st.expander(f"📘 {doc['api_name']}"):
                        st.caption(f"Repo: {doc.get('repo_url', 'N/A')} | Updated: {doc.get('last_updated', '')}")

                        col1, col2 = st.columns(2)
                        with col1:
                            if st.button("View", key=f"view_{doc['id']}"):
                                detail = requests.get(f"{BACKEND_URL}/docs/{doc['api_name']}", timeout=10)
                                if detail.status_code == 200:
                                    st.markdown(detail.json().get("content", ""))
                        with col2:
                            dl_url = f"{BACKEND_URL}/download/{doc['api_name']}"
                            st.markdown(f"[⬇ Download]({dl_url})", unsafe_allow_html=True)
        else:
            st.error("Failed to fetch documents.")
    except requests.exceptions.ConnectionError:
        st.error("Cannot connect to backend.")

# --- Upload Doc Page ---
elif page == "Upload Doc":
    st.header("Upload Existing Documentation")
    api_name = st.text_input("API Name", placeholder="payment-service-v1")
    uploaded_file = st.file_uploader("Upload .md or .txt file", type=["md", "txt"])

    if st.button("Upload", type="primary"):
        if not api_name:
            st.error("API name is required.")
        elif not uploaded_file:
            st.error("Please select a file.")
        else:
            with st.spinner("Uploading..."):
                try:
                    r = requests.post(
                        f"{BACKEND_URL}/upload-doc",
                        files={"file": (uploaded_file.name, uploaded_file, "text/plain")},
                        data={"api_name": api_name},
                        timeout=60,
                    )
                    if r.status_code == 200:
                        st.success(f"✅ Uploaded successfully: {api_name}")
                    else:
                        st.error(f"Error: {r.json().get('error', 'Unknown')}")
                except Exception as e:
                    st.error(f"Error: {e}")

# --- Health check in footer ---
st.sidebar.markdown("---")
try:
    h = requests.get(f"{BACKEND_URL}/health", timeout=3)
    data = h.json()
    st.sidebar.success("🟢 Backend: Online")
    ollama_status = "🟢 Online" if data.get("ollama") else "🔴 Offline"
    st.sidebar.info(f"Ollama: {ollama_status}")
except Exception:
    st.sidebar.error("🔴 Backend: Offline")
