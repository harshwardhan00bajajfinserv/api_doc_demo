from backend.services.ollama_service import generate_embedding
from backend.utils.logger import get_logger

logger = get_logger(__name__)

def get_embedding(text: str) -> list:
    """Generate and return embedding vector for text."""
    logger.info("Generating embedding...")
    return generate_embedding(text)

def batch_embeddings(texts: list[str]) -> list[list]:
    """Generate embeddings for a list of texts."""
    results = []
    for i, text in enumerate(texts):
        try:
            emb = generate_embedding(text)
            results.append(emb)
        except Exception as e:
            logger.error(f"Embedding failed for text {i}: {e}")
            results.append([])
    return results
