import re

# Patterns that suggest a file contains API/route definitions
API_PATTERNS = [
    r"@RestController", r"@RequestMapping", r"@GetMapping", r"@PostMapping",
    r"@PutMapping", r"@DeleteMapping",
    r"router\.(get|post|put|delete|patch)\(",
    r"app\.(get|post|put|delete|patch)\(",
    r"@app\.route", r"@router\.",
    r"FastAPI\(\)", r"APIRouter\(\)",
]

COMPILED = [re.compile(p) for p in API_PATTERNS]

def is_api_file(content: str) -> bool:
    """Return True if file likely contains API definitions."""
    return any(p.search(content) for p in COMPILED)

def filter_api_files(files: list[dict]) -> list[dict]:
    """Keep only files that appear to contain API/route code."""
    return [f for f in files if is_api_file(f["content"])]
