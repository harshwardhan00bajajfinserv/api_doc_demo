import os
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from backend.services import github_service, parser_service, chunking_service
from backend.services import ollama_service, embedding_service, rag_service
from backend.database import queries
from backend.utils.hashing import sha256_hash
from backend.config import config
from backend.utils.logger import get_logger

logger = get_logger(__name__)

def _extract_api_name(content: str, file_path: str) -> str:
    """Try to extract a meaningful API name from content or fall back to file path."""
    match = re.search(r"# (.+)", content)
    if match:
        return match.group(1).strip()[:80]
    return os.path.basename(file_path).rsplit(".", 1)[0]

def process_repo(repo_url: str) -> dict:
    """Main workflow: fetch → parse → chunk → embed → RAG → generate → store."""
    logger.info(f"Processing repo: {repo_url}")

    # Fetch latest commit
    try:
        commit_sha = github_service.get_latest_commit_sha(repo_url)
    except Exception as e:
        raise RuntimeError(f"GitHub error: {e}")

    # Fetch files
    files = github_service.fetch_repo_files(repo_url)
    if not files:
        return {"status": "no_files", "docs_generated": 0}

    # Filter to API files
    api_files = parser_service.filter_api_files(files)
    logger.info(f"API files found: {len(api_files)}")

    if not api_files:
        return {"status": "no_api_files", "docs_generated": 0}

    docs_generated = 0

    def process_file(file_info):
        path = file_info["path"]
        content = file_info["content"]
        source_hash = sha256_hash(content)

        # Skip if unchanged
        api_name = _extract_api_name(content, path)
        existing = queries.get_document(api_name)
        if existing and existing.get("source_hash") == source_hash:
            logger.info(f"Skipping unchanged: {api_name}")
            return 0

        chunks = chunking_service.chunk_code(content)
        count = 0
        for chunk in chunks:
            try:
                emb = embedding_service.get_embedding(chunk)
                similar = rag_service.get_similar_docs(emb)
                context = rag_service.build_rag_context(similar)
                doc_content = ollama_service.generate_documentation(chunk, context)

                chunk_api_name = api_name if len(chunks) == 1 else f"{api_name}_{count}"

                if queries.doc_exists(chunk_api_name):
                    queries.update_document(
                        chunk_api_name, doc_content, emb,
                        source_hash=source_hash,
                        embedding_model=config.EMBEDDING_MODEL,
                        last_commit_sha=commit_sha,
                    )
                else:
                    queries.insert_document(
                        chunk_api_name, doc_content, emb,
                        repo_url=repo_url,
                        source_hash=source_hash,
                        embedding_model=config.EMBEDDING_MODEL,
                        last_commit_sha=commit_sha,
                    )
                count += 1
            except Exception as e:
                logger.error(f"Error processing chunk in {path}: {e}")
        return count

    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {executor.submit(process_file, f): f["path"] for f in api_files}
        for future in as_completed(futures):
            try:
                docs_generated += future.result()
            except Exception as e:
                logger.error(f"File processing failed: {e}")

    return {"status": "success", "docs_generated": docs_generated, "commit_sha": commit_sha}

def store_uploaded_doc(api_name: str, content: str) -> int:
    """Store a manually uploaded document."""
    try:
        emb = embedding_service.get_embedding(content)
    except Exception:
        emb = []
    source_hash = sha256_hash(content)
    if queries.doc_exists(api_name):
        queries.update_document(api_name, content, emb, source_hash=source_hash,
                                embedding_model=config.EMBEDDING_MODEL)
        return -1
    return queries.insert_document(api_name, content, emb, source_hash=source_hash,
                                   embedding_model=config.EMBEDDING_MODEL)
