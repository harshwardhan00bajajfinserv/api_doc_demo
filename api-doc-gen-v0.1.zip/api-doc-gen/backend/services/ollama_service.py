import requests
import time
from backend.config import config
from backend.utils.logger import get_logger

logger = get_logger(__name__)

OLLAMA_BASE = config.OLLAMA_URL

def health_check() -> bool:
    try:
        r = requests.get(f"{OLLAMA_BASE}/api/tags", timeout=5)
        return r.status_code == 200
    except Exception:
        return False

def generate_embedding(text: str, retries: int = 3) -> list:
    for attempt in range(retries):
        try:
            r = requests.post(
                f"{OLLAMA_BASE}/api/embeddings",
                json={"model": config.EMBEDDING_MODEL, "prompt": text},
                timeout=60,
            )
            r.raise_for_status()
            return r.json().get("embedding", [])
        except Exception as e:
            logger.warning(f"Embedding attempt {attempt+1} failed: {e}")
            time.sleep(2)
    raise RuntimeError("Ollama embedding failed after retries.")

def generate_documentation(source_code: str, context: str = "", retries: int = 3) -> str:
    prompt = f"""You are a technical documentation writer.

{f'Existing similar documentation for reference:{chr(10)}{context}{chr(10)}' if context else ''}

Generate API documentation in Markdown for the following source code.
Include: API Name, Endpoint, HTTP Method, Description, Request Parameters,
Request Body, Response Body, Status Codes, Error Responses, Authentication,
Example Request, Example Response.

Source Code:
```
{source_code}
```

Output only Markdown documentation."""

    for attempt in range(retries):
        try:
            r = requests.post(
                f"{OLLAMA_BASE}/api/generate",
                json={"model": config.LLM_MODEL, "prompt": prompt, "stream": False},
                timeout=120,
            )
            r.raise_for_status()
            return r.json().get("response", "")
        except Exception as e:
            logger.warning(f"LLM attempt {attempt+1} failed: {e}")
            time.sleep(3)
    raise RuntimeError("Ollama LLM generation failed after retries.")
