import requests
from backend.config import config
from backend.utils.logger import get_logger

logger = get_logger(__name__)

SUPPORTED_EXTENSIONS = {".java", ".js", ".ts", ".py", ".go", ".kt", ".cs"}
IGNORE_DIRS = {"node_modules", "target", "build", "dist", ".git", ".idea", "venv", "__pycache__"}

def _headers():
    h = {"Accept": "application/vnd.github.v3+json"}
    if config.GITHUB_TOKEN:
        h["Authorization"] = f"token {config.GITHUB_TOKEN}"
    return h

def parse_repo_url(url: str):
    """Extract owner and repo from GitHub URL."""
    parts = url.rstrip("/").split("/")
    return parts[-2], parts[-1]

def get_latest_commit_sha(repo_url: str) -> str:
    owner, repo = parse_repo_url(repo_url)
    r = requests.get(
        f"https://api.github.com/repos/{owner}/{repo}/commits",
        headers=_headers(), params={"per_page": 1}, timeout=15
    )
    r.raise_for_status()
    return r.json()[0]["sha"]

def fetch_repo_files(repo_url: str) -> list[dict]:
    """Fetch all supported source files from repo. Returns list of {path, content}."""
    owner, repo = parse_repo_url(repo_url)
    files = []
    _walk_tree(owner, repo, "", files)
    logger.info(f"Fetched {len(files)} files from {repo_url}")
    return files

def _walk_tree(owner, repo, path, result):
    url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"
    try:
        r = requests.get(url, headers=_headers(), timeout=15)
        r.raise_for_status()
        items = r.json()
        if not isinstance(items, list):
            return
        for item in items:
            if item["type"] == "dir":
                if item["name"] not in IGNORE_DIRS:
                    _walk_tree(owner, repo, item["path"], result)
            elif item["type"] == "file":
                ext = "." + item["name"].rsplit(".", 1)[-1] if "." in item["name"] else ""
                if ext in SUPPORTED_EXTENSIONS:
                    content = _fetch_file_content(item["download_url"])
                    if content:
                        result.append({"path": item["path"], "content": content})
    except Exception as e:
        logger.warning(f"Error walking {path}: {e}")

def _fetch_file_content(download_url: str) -> str:
    try:
        r = requests.get(download_url, timeout=15)
        r.raise_for_status()
        return r.text
    except Exception as e:
        logger.warning(f"Could not fetch {download_url}: {e}")
        return ""
