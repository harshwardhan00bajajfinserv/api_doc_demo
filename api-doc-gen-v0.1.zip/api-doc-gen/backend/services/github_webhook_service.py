"""
Placeholder: GitHub Webhook Service
Future implementation will handle push events to trigger re-documentation.

Expected workflow:
  POST /webhook/github
  → Verify HMAC signature
  → Parse push event payload
  → Extract repo URL + commit SHA
  → Trigger document_service.process_repo(repo_url)
"""

def handle_webhook(payload: dict, signature: str) -> dict:
    raise NotImplementedError("Webhook handling not yet implemented.")

def verify_signature(payload_body: bytes, secret: str, signature: str) -> bool:
    raise NotImplementedError("Signature verification not yet implemented.")
