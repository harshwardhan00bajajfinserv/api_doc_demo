from backend.config import config

def chunk_code(content: str, max_size: int = None) -> list[str]:
    """
    Smart chunking: tries to split on class/function boundaries.
    Falls back to hard split if no boundaries found.
    """
    max_size = max_size or config.CHUNK_SIZE
    if len(content) <= max_size:
        return [content]

    # Try to split on common boundary markers
    boundaries = ["\nclass ", "\ndef ", "\npublic class ", "\nprivate ", "\n@"]
    chunks = []
    current = ""

    lines = content.splitlines(keepends=True)
    for line in lines:
        if len(current) + len(line) > max_size:
            # Check if we're at a boundary
            stripped = line.lstrip()
            at_boundary = any(stripped.startswith(b.strip()) for b in boundaries)
            if current and (at_boundary or len(current) >= max_size):
                chunks.append(current)
                current = line
            else:
                current += line
        else:
            current += line

    if current:
        chunks.append(current)

    # Fallback: hard-split if no line boundaries helped
    if not chunks or (len(chunks) == 1 and len(chunks[0]) > max_size):
        chunks = [content[i:i+max_size] for i in range(0, len(content), max_size)]

    return chunks
