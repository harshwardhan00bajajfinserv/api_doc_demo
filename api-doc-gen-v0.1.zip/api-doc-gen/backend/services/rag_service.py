from backend.database.queries import get_embeddings
from backend.utils.similarity import top_k_similar
from backend.config import config
from backend.utils.logger import get_logger

logger = get_logger(__name__)

def get_similar_docs(query_embedding: list, k: int = None) -> list:
    """Retrieve top-k similar documents using manual cosine similarity."""
    k = k or config.TOP_K
    all_docs = get_embeddings()
    if not all_docs:
        return []
    docs = [dict(d) for d in all_docs]
    return top_k_similar(query_embedding, docs, k=k)

def build_rag_context(similar_docs: list) -> str:
    """Build context string from similar docs."""
    if not similar_docs:
        return ""
    parts = ["Existing Documentation:\n"]
    for i, doc in enumerate(similar_docs, 1):
        parts.append(f"--- Doc {i}: {doc.get('api_name', 'Unknown')} ---\n{doc.get('content', '')}\n")
    return "\n".join(parts)
