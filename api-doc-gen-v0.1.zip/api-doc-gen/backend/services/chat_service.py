"""
Placeholder: RAG Chat Service
Future implementation will support Q&A over stored documentation.

Expected workflow:
  User question
  → get_embedding(question)
  → rag_service.get_similar_docs(embedding)
  → rag_service.build_rag_context(docs)
  → ollama_service.generate_answer(question, context)
  → Return answer
"""

def chat(question: str) -> str:
    raise NotImplementedError("Chat service not yet implemented.")
