from apscheduler.schedulers.background import BackgroundScheduler
from backend.database.queries import get_all_documents
from backend.services.document_service import process_repo
from backend.utils.logger import get_logger

logger = get_logger(__name__)
_scheduler = BackgroundScheduler()

def sync_all_repos():
    """Scheduled job: re-process all tracked repos."""
    logger.info("Scheduled sync started.")
    docs = get_all_documents()
    repo_urls = {d["repo_url"] for d in docs if d.get("repo_url")}
    for url in repo_urls:
        try:
            result = process_repo(url)
            logger.info(f"Synced {url}: {result}")
        except Exception as e:
            logger.error(f"Sync failed for {url}: {e}")
    logger.info("Scheduled sync complete.")

def start_scheduler():
    if not _scheduler.running:
        _scheduler.add_job(sync_all_repos, "cron", hour=0, minute=0, id="daily_sync")
        _scheduler.start()
        logger.info("Scheduler started (daily at midnight).")

def stop_scheduler():
    if _scheduler.running:
        _scheduler.shutdown()
