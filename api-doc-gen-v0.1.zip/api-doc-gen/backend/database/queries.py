from backend.database.connection import db_cursor
from backend.utils.logger import get_logger

logger = get_logger(__name__)

MIGRATE_SQL = """
ALTER TABLE docs
    ADD COLUMN IF NOT EXISTS repo_url TEXT,
    ADD COLUMN IF NOT EXISTS source_hash TEXT,
    ADD COLUMN IF NOT EXISTS embedding_model TEXT,
    ADD COLUMN IF NOT EXISTS last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ADD COLUMN IF NOT EXISTS last_commit_sha TEXT;
"""

def run_migrations():
    with db_cursor() as cur:
        cur.execute(MIGRATE_SQL)
    logger.info("DB migrations applied.")

def insert_document(api_name, content, embeddings, repo_url=None,
                    source_hash=None, embedding_model=None, last_commit_sha=None):
    with db_cursor() as cur:
        cur.execute(
            """INSERT INTO docs (api_name, content, embeddings, repo_url, source_hash,
               embedding_model, last_commit_sha, last_updated)
               VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
               RETURNING id""",
            (api_name, content, embeddings, repo_url, source_hash, embedding_model, last_commit_sha)
        )
        return cur.fetchone()["id"]

def update_document(api_name, content, embeddings, source_hash=None,
                    embedding_model=None, last_commit_sha=None):
    with db_cursor() as cur:
        cur.execute(
            """UPDATE docs SET content=%s, embeddings=%s, source_hash=%s,
               embedding_model=%s, last_commit_sha=%s, last_updated=NOW()
               WHERE api_name=%s""",
            (content, embeddings, source_hash, embedding_model, last_commit_sha, api_name)
        )

def get_document(api_name: str):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM docs WHERE api_name=%s LIMIT 1", (api_name,))
        return cur.fetchone()

def get_all_documents():
    with db_cursor() as cur:
        cur.execute("SELECT * FROM docs ORDER BY last_updated DESC")
        return cur.fetchall()

def get_embeddings():
    """Return all docs with embeddings for similarity search."""
    with db_cursor() as cur:
        cur.execute("SELECT id, api_name, content, embeddings FROM docs WHERE embeddings IS NOT NULL")
        return cur.fetchall()

def get_repo_documents(repo_url: str):
    with db_cursor() as cur:
        cur.execute("SELECT * FROM docs WHERE repo_url=%s", (repo_url,))
        return cur.fetchall()

def doc_exists(api_name: str) -> bool:
    with db_cursor() as cur:
        cur.execute("SELECT 1 FROM docs WHERE api_name=%s LIMIT 1", (api_name,))
        return cur.fetchone() is not None
