import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Database
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", 5432))
    DB_NAME = os.getenv("DB_NAME", "apidocs")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")

    # Ollama
    OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
    LLM_MODEL = os.getenv("LLM_MODEL", "llama3")
    EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "nomic-embed-text")

    # GitHub
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")

    # App settings
    CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", 3000))
    TOP_K = int(os.getenv("TOP_K", 5))
    MAX_UPLOAD_SIZE = 5 * 1024 * 1024  # 5MB

config = Config()
