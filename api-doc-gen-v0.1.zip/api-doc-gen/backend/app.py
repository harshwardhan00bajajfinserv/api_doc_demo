from flask import Flask, jsonify
from backend.routes.generate_routes import generate_bp
from backend.routes.docs_routes import docs_bp
from backend.routes.download_routes import download_bp
from backend.routes.upload_routes import upload_bp
from backend.database.queries import run_migrations
from backend.services.scheduler_service import start_scheduler
from backend.services.ollama_service import health_check
from backend.utils.logger import get_logger

logger = get_logger(__name__)

def create_app():
    app = Flask(__name__)

    # Register blueprints
    app.register_blueprint(generate_bp)
    app.register_blueprint(docs_bp)
    app.register_blueprint(download_bp)
    app.register_blueprint(upload_bp)

    @app.route("/health", methods=["GET"])
    def health():
        ollama_ok = health_check()
        return jsonify({"status": "ok", "ollama": ollama_ok}), 200

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"error": "Not found"}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({"error": "Internal server error"}), 500

    return app


if __name__ == "__main__":
    import os
    logger.info("Running DB migrations...")
    try:
        run_migrations()
    except Exception as e:
        logger.warning(f"Migration warning: {e}")

    logger.info("Starting scheduler...")
    start_scheduler()

    app = create_app()
    port = int(os.getenv("FLASK_PORT", 5000))
    debug = os.getenv("FLASK_DEBUG", "false").lower() == "true"
    logger.info(f"Starting Flask on port {port}")
    app.run(host="0.0.0.0", port=port, debug=debug)
