from flask import Blueprint, jsonify
from backend.database.queries import get_document, get_all_documents
from backend.utils.logger import get_logger

docs_bp = Blueprint("docs", __name__)
logger = get_logger(__name__)

@docs_bp.route("/docs/<api_name>", methods=["GET"])
def get_doc(api_name):
    doc = get_document(api_name)
    if not doc:
        return jsonify({"error": "Not found"}), 404
    return jsonify(dict(doc)), 200

@docs_bp.route("/docs", methods=["GET"])
def list_docs():
    docs = get_all_documents()
    return jsonify([{"id": d["id"], "api_name": d["api_name"],
                     "repo_url": d.get("repo_url"), "last_updated": str(d.get("last_updated", ""))}
                    for d in docs]), 200
