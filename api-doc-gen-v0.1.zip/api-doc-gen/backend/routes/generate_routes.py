from flask import Blueprint, request, jsonify
from backend.services.document_service import process_repo
from backend.utils.hashing import validate_repo_url
from backend.utils.logger import get_logger

generate_bp = Blueprint("generate", __name__)
logger = get_logger(__name__)

@generate_bp.route("/generate-docs", methods=["POST"])
def generate_docs():
    data = request.get_json(silent=True) or {}
    repo_url = data.get("repo_url", "").strip()

    if not repo_url:
        return jsonify({"error": "repo_url is required"}), 400
    if not validate_repo_url(repo_url):
        return jsonify({"error": "Invalid GitHub repository URL"}), 400

    logger.info(f"Generate docs request: {repo_url}")
    try:
        result = process_repo(repo_url)
        return jsonify(result), 200
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 502
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return jsonify({"error": "Internal server error"}), 500
