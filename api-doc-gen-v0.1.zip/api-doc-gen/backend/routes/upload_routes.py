from flask import Blueprint, request, jsonify
from backend.services.document_service import store_uploaded_doc
from backend.config import config
from backend.utils.logger import get_logger

upload_bp = Blueprint("upload", __name__)
logger = get_logger(__name__)

ALLOWED_EXTENSIONS = {".md", ".txt"}

@upload_bp.route("/upload-doc", methods=["POST"])
def upload_doc():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    filename = file.filename or ""
    ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    if ext not in ALLOWED_EXTENSIONS:
        return jsonify({"error": "Only .md and .txt files allowed"}), 400

    content = file.read()
    if len(content) > config.MAX_UPLOAD_SIZE:
        return jsonify({"error": "File too large (max 5MB)"}), 413

    api_name = request.form.get("api_name") or filename.rsplit(".", 1)[0]
    text = content.decode("utf-8", errors="ignore")

    try:
        doc_id = store_uploaded_doc(api_name, text)
        return jsonify({"status": "stored", "api_name": api_name, "id": doc_id}), 200
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        return jsonify({"error": "Storage failed"}), 500
