from flask import Blueprint, Response
from backend.database.queries import get_document

download_bp = Blueprint("download", __name__)

@download_bp.route("/download/<api_name>", methods=["GET"])
def download_doc(api_name):
    doc = get_document(api_name)
    if not doc:
        return Response("Not found", status=404)
    filename = f"{api_name.replace(' ', '_')}.md"
    return Response(
        doc["content"],
        mimetype="text/markdown",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )
