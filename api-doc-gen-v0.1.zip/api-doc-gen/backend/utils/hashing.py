import hashlib

def sha256_hash(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()

def validate_repo_url(url: str) -> bool:
    """Basic GitHub URL validation."""
    return url.startswith("https://github.com/") and len(url.split("/")) >= 5
