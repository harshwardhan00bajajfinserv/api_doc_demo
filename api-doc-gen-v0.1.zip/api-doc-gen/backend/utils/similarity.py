import math
from typing import List

def cosine_similarity(vec_a: List[float], vec_b: List[float]) -> float:
    """Manual cosine similarity — no pgvector needed."""
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    mag_a = math.sqrt(sum(a * a for a in vec_a))
    mag_b = math.sqrt(sum(b * b for b in vec_b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)

def top_k_similar(query_embedding: List[float], docs: list, k: int = 5) -> list:
    """Return top-k docs sorted by cosine similarity."""
    scored = []
    for doc in docs:
        emb = doc.get("embeddings") or []
        score = cosine_similarity(query_embedding, emb)
        scored.append({**doc, "score": score})
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:k]
