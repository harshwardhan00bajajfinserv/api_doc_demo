import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.utils.similarity import cosine_similarity, top_k_similar

def test_cosine_identical():
    v = [1.0, 0.0, 0.0]
    assert abs(cosine_similarity(v, v) - 1.0) < 1e-6

def test_cosine_orthogonal():
    a = [1.0, 0.0]
    b = [0.0, 1.0]
    assert abs(cosine_similarity(a, b)) < 1e-6

def test_cosine_empty():
    assert cosine_similarity([], [1.0]) == 0.0

def test_top_k():
    docs = [
        {"id": 1, "api_name": "a", "content": "x", "embeddings": [1.0, 0.0]},
        {"id": 2, "api_name": "b", "content": "y", "embeddings": [0.0, 1.0]},
        {"id": 3, "api_name": "c", "content": "z", "embeddings": [0.9, 0.1]},
    ]
    results = top_k_similar([1.0, 0.0], docs, k=2)
    assert len(results) == 2
    assert results[0]["api_name"] == "a"
