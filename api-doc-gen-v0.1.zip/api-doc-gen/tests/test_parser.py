import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.services.parser_service import is_api_file, filter_api_files

def test_detects_flask_route():
    content = "@app.route('/users', methods=['GET'])\ndef get_users(): pass"
    assert is_api_file(content) is True

def test_detects_spring_controller():
    content = "@RestController\n@RequestMapping('/api')\npublic class UserController {}"
    assert is_api_file(content) is True

def test_ignores_non_api_file():
    content = "def helper(x):\n    return x * 2\n"
    assert is_api_file(content) is False

def test_filter_keeps_api_files():
    files = [
        {"path": "a.py", "content": "@app.route('/a')"},
        {"path": "b.py", "content": "def util(): pass"},
    ]
    result = filter_api_files(files)
    assert len(result) == 1
    assert result[0]["path"] == "a.py"
