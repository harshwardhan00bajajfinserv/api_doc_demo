import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.utils.hashing import sha256_hash, validate_repo_url

def test_hash_is_deterministic():
    h1 = sha256_hash("hello world")
    h2 = sha256_hash("hello world")
    assert h1 == h2

def test_hash_changes_with_content():
    assert sha256_hash("abc") != sha256_hash("xyz")

def test_valid_github_url():
    assert validate_repo_url("https://github.com/owner/repo") is True

def test_invalid_url():
    assert validate_repo_url("https://gitlab.com/owner/repo") is False
    assert validate_repo_url("not-a-url") is False
