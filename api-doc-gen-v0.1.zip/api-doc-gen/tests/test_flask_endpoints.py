import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from unittest.mock import patch, MagicMock
from backend.app import create_app

@pytest.fixture
def client():
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c

def test_health_endpoint(client):
    with patch("backend.routes.generate_routes.process_repo"):
        with patch("backend.app.health_check", return_value=True):
            r = client.get("/health")
            assert r.status_code == 200

def test_generate_missing_body(client):
    r = client.post("/generate-docs", json={})
    assert r.status_code == 400

def test_generate_invalid_url(client):
    r = client.post("/generate-docs", json={"repo_url": "https://gitlab.com/a/b"})
    assert r.status_code == 400

def test_generate_valid_url(client):
    with patch("backend.routes.generate_routes.process_repo",
               return_value={"status": "success", "docs_generated": 2}):
        r = client.post("/generate-docs", json={"repo_url": "https://github.com/owner/repo"})
        assert r.status_code == 200
        assert r.json["docs_generated"] == 2

def test_docs_not_found(client):
    with patch("backend.routes.docs_routes.get_document", return_value=None):
        r = client.get("/docs/nonexistent")
        assert r.status_code == 404

def test_download_not_found(client):
    with patch("backend.routes.download_routes.get_document", return_value=None):
        r = client.get("/download/nonexistent")
        assert r.status_code == 404
