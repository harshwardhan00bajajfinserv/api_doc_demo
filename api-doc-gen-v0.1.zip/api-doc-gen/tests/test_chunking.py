import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.services.chunking_service import chunk_code

def test_small_content_not_chunked():
    content = "def hello(): pass"
    chunks = chunk_code(content, max_size=3000)
    assert len(chunks) == 1
    assert chunks[0] == content

def test_large_content_is_chunked():
    content = "x" * 6001
    chunks = chunk_code(content, max_size=3000)
    assert len(chunks) > 1

def test_chunks_cover_all_content():
    content = "abc\n" * 2000
    chunks = chunk_code(content, max_size=3000)
    combined = "".join(chunks)
    assert combined == content
